

<?php $__env->startPush('styles_top'); ?>
    <link rel="stylesheet" href="/assets/default/vendors/select2/select2.min.css">
    <link rel="stylesheet" href="/assets/default/vendors/daterangepicker/daterangepicker.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('web.default.panel.requirements.requirements_includes.progress', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php if(Session::has('success')): ?>
        <div class="container d-flex justify-content-center mt-80">
            <p class="alert alert-success w-75 text-center"> <?php echo e(Session::get('success')); ?> </p>
        </div>
    <?php else: ?>
        <?php if(!empty($requirementUploaded) and $requirementUploaded == true): ?>
            <?php if($requirementApproved == "approved"): ?>
                <?php if($currentStep == 1): ?>
                    <div class="container d-flex justify-content-center mt-80 flex-column align-items-center">
                        <p class="alert alert-success w-75 text-center">
                            لقد تم بالفعل رفع متطلبات القبول وتم الموافقة عليها يرجي الذهاب للخطوة التاليه للدفع
                        </p>

                        <a href="/bundles/<?php echo e($bundle->slug); ?>" class="btn btn-primary p-5 mt-20 w-25">للذهاب للدفع رسوم البرنامج اضغط هنا</a>
                    </div>
                <?php elseif($currentStep == 2): ?>
                    <?php echo $__env->make('web.default.panel.requirements.requirements_includes.financial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            <?php elseif($requirementApproved == "pending"): ?>
                <div class="container d-flex justify-content-center mt-80">
                    <p class="alert alert-info w-75 text-center">
                        لقد تم بالفعل رفع متطلبات القبول يرجي الانتظار حتي يتم مراجعتها
                    </p>
                </div>
            <?php elseif($requirementApproved == "rejected"): ?>
                <div class="container d-flex justify-content-center mt-80">
                    <p class="alert alert-danger w-75 text-center text-white">
                        لقد تم رفض الملفات التي قمت برفعها يرجي مراجعة الميل لمشاهدة السبب ثم ارفع الملفات مرة اخري
                    </p>
                </div>

                <?php echo $__env->make('web.default.panel.requirements.requirements_includes.basic_information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php else: ?>
            <?php if(!empty($currentStep) and $currentStep == 1): ?>
                <?php echo $__env->make('web.default.panel.requirements.requirements_includes.basic_information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>





    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts_bottom'); ?>
    <script src="/assets/vendors/cropit/jquery.cropit.js"></script>
    <script src="/assets/default/js/parts/img_cropit.min.js"></script>
    <script src="/assets/default/vendors/select2/select2.min.js"></script>

    <script>
        var editEducationLang = '<?php echo e(trans('site.edit_education')); ?>';
        var editExperienceLang = '<?php echo e(trans('site.edit_experience')); ?>';
        var saveSuccessLang = '<?php echo e(trans('webinars.success_store')); ?>';
        var saveErrorLang = '<?php echo e(trans('site.store_error_try_again')); ?>';
        var notAccessToLang = '<?php echo e(trans('public.not_access_to_this_content')); ?>';
    </script>

    <script src="/assets/default/js/panel/user_setting.min.js"></script>



<?php $__env->stopPush(); ?>

<?php echo $__env->make(getTemplate() . '.panel.layouts.panel_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\New folder\lms-system-v1\resources\views/web/default/panel/requirements/index.blade.php ENDPATH**/ ?>