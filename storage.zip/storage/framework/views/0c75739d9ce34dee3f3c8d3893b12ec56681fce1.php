

<?php $__env->startSection('content'); ?>

    <?php if(!empty($overdueInstallmentsCount) and $overdueInstallmentsCount > 0): ?>
        <div class="d-flex align-items-center mb-20 p-15 danger-transparent-alert">
            <div class="danger-transparent-alert__icon d-flex align-items-center justify-content-center">
                <i data-feather="credit-card" width="18" height="18" class=""></i>
            </div>
            <div class="ml-10">
                <div class="font-14 font-weight-bold "><?php echo e(trans('update.overdue_installments')); ?></div>
                <div class="font-12 "><?php echo e(trans('update.you_have_count_overdue_installments_please_pay_them_to_avoid_restrictions_and_negative_effects_on_your_account',['count' => $overdueInstallmentsCount])); ?></div>
            </div>
        </div>
    <?php endif; ?>

    
    <section>
        <h2 class="section-title"><?php echo e(trans('update.installments_overview')); ?></h2>

        <div class="activities-container mt-25 p-20 p-lg-35">
            <div class="row">
                <div class="col-6 col-md-3 mt-30 mt-md-0 d-flex align-items-center justify-content-center">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img src="/assets/default/img/activity/129.png" width="64" height="64" alt="">
                        <strong class="font-30 text-dark-blue font-weight-bold mt-5"><?php echo e($openInstallmentsCount); ?></strong>
                        <span class="font-16 text-gray font-weight-500"><?php echo e(trans('update.open_installments')); ?></span>
                    </div>
                </div>

                <div class="col-6 col-md-3 mt-30 mt-md-0 d-flex align-items-center justify-content-center">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img src="/assets/default/img/activity/130.png" width="64" height="64" alt="">
                        <strong class="font-30 text-dark-blue font-weight-bold mt-5"><?php echo e($pendingVerificationCount); ?></strong>
                        <span class="font-16 text-gray font-weight-500"><?php echo e(trans('update.pending_verification')); ?></span>
                    </div>
                </div>

                <div class="col-6 col-md-3 mt-30 mt-md-0 d-flex align-items-center justify-content-center mt-5 mt-md-0">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img src="/assets/default/img/activity/127.png" width="64" height="64" alt="">
                        <strong class="font-30 text-dark-blue font-weight-bold mt-5"><?php echo e($finishedInstallmentsCount); ?></strong>
                        <span class="font-16 text-gray font-weight-500"><?php echo e(trans('update.finished_installments')); ?></span>
                    </div>
                </div>

                <div class="col-6 col-md-3 mt-30 mt-md-0 d-flex align-items-center justify-content-center mt-5 mt-md-0">
                    <div class="d-flex flex-column align-items-center text-center">
                        <img src="/assets/default/img/activity/128.png" width="64" height="64" alt="">
                        <strong class="font-30 text-dark-blue font-weight-bold mt-5"><?php echo e($overdueInstallmentsCount); ?></strong>
                        <span class="font-16 text-gray font-weight-500"><?php echo e(trans('update.overdue_installments')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="mt-25">
        <div class="d-flex align-items-start align-items-md-center justify-content-between flex-column flex-md-row">
            <h2 class="section-title"><?php echo e(trans('update.my_installments')); ?></h2>
        </div>

        <?php if(!empty($orders) and count($orders)): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $orderItem = $order->getItem();
                    $itemType = $order->getItemType();
                    $itemPrice = $order->getItemPrice();
                ?>

                <?php if(!empty($orderItem)): ?>
                    <div class="row mt-30">
                        <div class="col-12">
                            <div class="webinar-card webinar-list panel-installment-card d-flex">
                                <div class="image-box">
                                    <?php if(in_array($itemType, ['course', 'bundle'])): ?>
                                        <img src="<?php echo e($orderItem->getImage()); ?>" class="img-cover" alt="">
                                    <?php elseif($itemType == 'product'): ?>
                                        <img src="<?php echo e($orderItem->thumbnail); ?>" class="img-cover" alt="">
                                    <?php elseif($itemType == "subscribe"): ?>
                                        <div class="d-flex align-items-center justify-content-center w-100 h-100">
                                            <img src="/assets/default/img/icons/installment/subscribe_default.svg" alt="">
                                        </div>
                                    <?php elseif($itemType == "registrationPackage"): ?>
                                        <div class="d-flex align-items-center justify-content-center w-100 h-100">
                                            <img src="/assets/default/img/icons/installment/reg_package_default.svg" alt="">
                                        </div>
                                    <?php endif; ?>

                                    <?php if($order->isCompleted()): ?>
                                        <span class="badge badge-secondary"><?php echo e(trans('update.completed')); ?></span>
                                    <?php elseif($order->status == "open"): ?>
                                        <span class="badge badge-primary"><?php echo e(trans('public.open')); ?></span>
                                    <?php elseif($order->status == "rejected"): ?>
                                        <span class="badge badge-danger"><?php echo e(trans('public.rejected')); ?></span>
                                    <?php elseif($order->status == "canceled"): ?>
                                        <span class="badge badge-danger"><?php echo e(trans('public.canceled')); ?></span>
                                    <?php elseif($order->status == "pending_verification"): ?>
                                        <span class="badge badge-warning"><?php echo e(trans('update.pending_verification')); ?></span>
                                    <?php elseif($order->status == "refunded"): ?>
                                        <span class="badge badge-secondary"><?php echo e(trans('update.refunded')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="webinar-card-body w-100 d-flex flex-column">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                            <h3 class="font-16 text-dark-blue font-weight-bold"><?php echo e($orderItem->title); ?></h3>

                                            <?php if($order->has_overdue): ?>
                                                <span class="badge badge-outlined-danger ml-10"><?php echo e(trans('update.overdue')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <?php if(!in_array($order->status, ['refunded', 'canceled']) or $order->isCompleted()): ?>
                                            <div class="btn-group dropdown table-actions">
                                                <button type="button" class="btn-transparent dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i data-feather="more-vertical" height="20"></i>
                                                </button>
                                                <div class="dropdown-menu ">

                                                    <?php if($order->status == "open"): ?>
                                                        <a href="/panel/financial/installments/<?php echo e($order->id); ?>/pay_upcoming_part" target="_blank" class="webinar-actions d-block mt-10"><?php echo e(trans('update.pay_upcoming_part')); ?></a>
                                                    <?php endif; ?>

                                                    <?php if(!in_array($order->status, ['refunded', 'canceled'])): ?>
                                                        <a href="/panel/financial/installments/<?php echo e($order->id); ?>/details" target="_blank" class="webinar-actions d-block mt-10"><?php echo e(trans('update.view_details')); ?></a>
                                                    <?php endif; ?>

                                                    <?php if($itemType == "course" and ($order->isCompleted() or $order->status == "open")): ?>
                                                        <a href="<?php echo e($orderItem->getLearningPageUrl()); ?>" target="_blank" class="webinar-actions d-block mt-10"><?php echo e(trans('update.learning_page')); ?></a>
                                                    <?php endif; ?>

                                                    

                                                    <?php if($order->status == "pending_verification" and getInstallmentsSettings("allow_cancel_verification")): ?>
                                                        <a href="/panel/financial/installments/<?php echo e($order->id); ?>/cancel" class="webinar-actions d-block mt-10 text-danger delete-action" data-title="<?php echo e(trans('public.deleteAlertHint')); ?>" data-confirm="<?php echo e(trans('update.yes_cancel')); ?>"><?php echo e(trans('public.cancel')); ?></a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                    </div>

                                    <div class="d-flex align-items-center justify-content-between flex-wrap mt-auto">
                                        <div class="d-flex align-items-start flex-column mt-20 mr-15">
                                            <span class="stat-title"><?php echo e(trans('update.item_type')); ?>:</span>
                                            <span class="stat-value"><?php echo e(trans('update.item_type_'.$itemType)); ?></span>
                                        </div>

                                        <div class="d-flex align-items-start flex-column mt-20 mr-15">
                                            <span class="stat-title"><?php echo e(trans('panel.purchase_date')); ?>:</span>
                                            <span class="stat-value"><?php echo e(dateTimeFormat($order->created_at, 'j M Y H:i')); ?></span>
                                        </div>

                                        <div class="d-flex align-items-start flex-column mt-20 mr-15">
                                            <span class="stat-title"><?php echo e(trans('update.upfront')); ?>:</span>
                                            <span class="stat-value"><?php echo e(!empty($order->selectedInstallment->upfront) ? handlePrice($order->selectedInstallment->getUpfront($itemPrice)) : '-'); ?></span>
                                        </div>

                                        <div class="d-flex align-items-start flex-column mt-20 mr-15">
                                            <span class="stat-title"><?php echo e(trans('update.total_installments')); ?>:</span>
                                            <span class="stat-value"><?php echo e(trans('update.total_parts_count', ['count' => $order->selectedInstallment->steps_count])); ?> (<?php echo e(handlePrice($order->selectedInstallment->totalPayments($itemPrice, false))); ?>)</span>
                                        </div>

                                        <?php if($order->status == "open" or $order->status == "pending_verification"): ?>
                                            <div class="d-flex align-items-start flex-column mt-20 mr-15">
                                                <span class="stat-title"><?php echo e(trans('update.remained_installments')); ?>:</span>
                                                <span class="stat-value"><?php echo e(trans('update.total_parts_count', ['count' => $order->remained_installments_count])); ?> (<?php echo e(handlePrice($order->remained_installments_amount)); ?>)</span>
                                            </div>

                                            <?php if(!empty($order->upcoming_installment)): ?>
                                                <div class="d-flex align-items-start flex-column mt-20 mr-15">
                                                    <span class="stat-title"><?php echo e(trans('update.upcoming_installment')); ?>:</span>
                                                    <span class="stat-value"><?php echo e(dateTimeFormat((($order->upcoming_installment->deadline * 86400) + $order->bundle->start_date), 'j M Y')); ?> (<?php echo e(handlePrice($order->upcoming_installment->getPrice($itemPrice))); ?>)</span>
                                                </div>
                                            <?php endif; ?>

                                            <?php if($order->has_overdue): ?>
                                                <div class="d-flex align-items-start flex-column mt-20 mr-15">
                                                    <span class="stat-title"><?php echo e(trans('update.overdue_installments')); ?>:</span>
                                                    <span class="stat-value"><?php echo e($order->overdue_count); ?> (<?php echo e(handlePrice($order->overdue_amount)); ?>)</span>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="my-30">
                <?php echo e($orders->appends(request()->input())->links('vendor.pagination.panel')); ?>

            </div>
        <?php else: ?>
            <?php echo $__env->make('web.default.includes.no-result',[
                    'file_name' => 'webinar.png',
                    'title' => trans('update.you_not_have_any_installment'),
                    'hint' =>  trans('update.you_not_have_any_installment_hint'),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts_bottom'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make(getTemplate() .'.panel.layouts.panel_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\lms\resources\views/web/default/panel/financial/installments/lists.blade.php ENDPATH**/ ?>