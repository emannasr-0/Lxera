<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>قائمة بمتطلبات القبول</h1>
        </div>


        <?php if(Session::has('success')): ?>
            <div class="container d-flex justify-content-center mt-80">
                <p class="alert alert-success w-75 text-center"> <?php echo e(Session::get('success')); ?> </p>
            </div>
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            <div class="container d-flex justify-content-center mt-80">
                <p class="alert alert-success w-75 text-center"> <?php echo e(Session::get('error')); ?> </p>
            </div>
        <?php endif; ?>
        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="container d-flex justify-content-center mt-80">
                <p class="alert alert-danger w-75 text-center fs-3"> <?php echo e('يرجي تسجيل سبب الرفض '); ?> </p>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <div class="section-body">

            <div class="row">
                <div class="col-12 col-md-12">
                    <div class="card">

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped font-14 ">
                                    <tr>
                                        <th><?php echo e('Index'); ?></th>
                                        <th class="text-left"><?php echo e('كود الطالب'); ?></th>
                                        <th class="text-left"><?php echo e('اسم الطالب'); ?></th>
                                        <th><?php echo e('البرنامج المسجل اليه'); ?></th>
                                        <th><?php echo e('التخصص'); ?></th>
                                        <th><?php echo e('مرفق الهوية'); ?></th>
                                        <th><?php echo e('مرفق متطلبات القبول'); ?></th>
                                        <th><?php echo e('حالة الطلب'); ?></th>
                                        <th><?php echo e('الأدمن'); ?></th>
                                        <th><?php echo e('تاريخ ارسال الطلب'); ?></th>

                                        <th width="120"><?php echo e('الأجراءات'); ?></th>
                                    </tr>
                                    <?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td><?php echo e(++$index); ?></td>
                                            <td class="text-left"><?php echo e($requirement->bundleStudent->student->registeredUser->user_code); ?>

                                            </td>
                                            <td class="text-left">
                                                <?php echo e($requirement->bundleStudent->student ? $requirement->bundleStudent->student->en_name : ''); ?>


                                            </td>


                                            <td><?php echo e($requirement->bundleStudent->bundle->category->slug); ?></td>

                                            <td><?php echo e($requirement->bundleStudent->bundle->slug); ?></td>

                                            <td>
                                                <a href="/store/<?php echo e($requirement->identity_attachment); ?>" target="_blank">
                                                    <?php if(pathinfo($requirement->identity_attachment, PATHINFO_EXTENSION) != 'pdf'): ?>
                                                        <img src="/store/<?php echo e($requirement->identity_attachment); ?>"
                                                            alt="identity_attachment" width="100px">
                                                    <?php else: ?>
                                                        pdf ملف <i class="fas fa-file font-20"></i>

                                                    <?php endif; ?>
                                                </a>
                                            </td>

                                            <td>
                                                <a href="/store/<?php echo e($requirement->admission_attachment); ?>" target="_blank" class="text-black">
                                                    pdf ملف <i class="fas fa-file font-20"></i>
                                                </a>
                                            </td>

                                            <td>
                                                <?php if($requirement->status=="pending"): ?>
                                                <span class="text-success"> معلق</span>
                                                <?php elseif($requirement->status=="approved"): ?>
                                                <span class="text-primary"> تم الموافقة عليه</span>
                                                <?php elseif($requirement->status=="rejected"): ?>
                                                <span class="text-danger"> تم رفضه</span>
                                                <?php endif; ?>
                                            </td>

                                            <td><?php echo e($requirement->admin ? $requirement->admin->full_name : ''); ?>

                                            </td>

                                            <td class="font-12">
                                                <?php echo e(dateTimeFormat($requirement->created_at, 'Y M j | H:i')); ?></td>

                                            
                                            <td width="200" class="">

                                                <div class="d-flex justify-content-center align-items-baseline gap-3">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_requirements_approve')): ?>
                                                        

                                                        
                                                        <?php echo $__env->make('admin.includes.delete_button', [
                                                            'url' =>
                                                                getAdminPanelUrl() .
                                                                '/requirements/' .
                                                                $requirement->id .
                                                                '/approve',
                                                            'btnClass' =>
                                                                'btn btn-primary d-flex align-items-center btn-sm mt-1 ml-3',
                                                            'btnText' =>
                                                                '<i class="fa fa-check"></i><span class="ml-2"> قبول' .
                                                                // trans('admin/main.approve') .
                                                                '</span>',
                                                            'hideDefaultClass' => true,
                                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_requirements_reject')): ?>
                                                        <?php echo $__env->make('admin.includes.confirm_delete_button', [
                                                            'url' =>
                                                                getAdminPanelUrl() .
                                                                '/requirements/' .
                                                                $requirement->id .
                                                                '/reject',
                                                            'btnClass' =>
                                                                'btn btn-danger d-flex align-items-center btn-sm mt-1',
                                                            'btnText' =>
                                                                '<i class="fa fa-times"></i><span class="ml-2">' .
                                                                trans('admin/main.reject') .
                                                                '</span>',
                                                            'hideDefaultClass' => true,
                                                            'id' => $requirement->id
                                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>

                        <div class="card-footer text-center">
                            <?php echo e($requirements->links()); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>




<?php $__env->startPush('libraries_top'); ?>
    <link rel="stylesheet" href="/assets/admin/vendor/owl.carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="/assets/admin/vendor/owl.carousel/owl.theme.min.css">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\lms\resources\views/admin/requirements/index.blade.php ENDPATH**/ ?>