<?php $__env->startPush('styles_top'); ?>
    <link rel="stylesheet" href="/assets/default/vendors/select2/select2.min.css">
    <link rel="stylesheet" href="/assets/default/vendors/daterangepicker/daterangepicker.min.css">
<?php $__env->stopPush(); ?>

<style>
    .requirement-card {
        /* width: 100%;
    background-color: white; */
        padding: 70px;
        box-shadow: 0px 0px 10px 0px #00000073;
    }

    .requirement-head {
        top: -15px;
        right: 30px;
        max-width: 85%;
    }
</style>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('web.default.panel.requirements.requirements_includes.progress', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="container d-flex mt-80 flex-wrap flex-md-nowrap">
        <?php if(count($studentBundles)>0): ?>
            <?php $__currentLoopData = $studentBundles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentBundle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section
                    class="requirement-card bg-white w-100 position-relative d-flex justify-content-center align-items-center rounded-sm mb-80 ml-50">
                    <h2 class="position-absolute bg-white p-5 requirement-head">
                        متطلبات القبول ل <?php echo e(clean($studentBundle->bundle->title, 't')); ?></h2>
                    <?php if(empty($studentBundle->studentRequirement)): ?>
                        <div class="w-100 text-center">
                            <p class="alert alert-info text-center">
                                لم يتم رفع متطلبات القبول بعد ، يرجي الضعط علي الزر للذهاب لصفحة متطلبات القبول
                            </p>
                            <a href="/panel/bundles/<?php echo e($studentBundle->id); ?>/requirements"
                                class="btn btn-success p-5 mt-20 bg-secondary">للذهاب لرفع ملفات متطلبات القبول اضغط هنا</a>
                        </div>
                    <?php else: ?>
                        <?php if($studentBundle->studentRequirement->status == 'pending'): ?>
                            <div class="w-100 text-center">
                                <p class="alert alert-info text-center">
                                    لقد تم بالفعل رفع متطلبات القبول يرجي الانتظار حتي يتم مراجعتها
                                </p>
                            </div>
                        <?php elseif($studentBundle->studentRequirement->status == 'approved'): ?>
                            <div class="w-100 text-center">
                                <p class="alert alert-success text-center">
                                    لقد تم بالفعل رفع متطلبات القبول وتم الموافقة عليها يرجي الذهاب للخطوة التاليه للدفع
                                </p>
                                <a href="/bundles/<?php echo e($studentBundle->bundle->slug); ?>"
                                    class="btn btn-primary p-5 mt-20">للذهاب للدفع
                                    رسوم البرنامج اضغط هنا</a>
                            </div>
                        <?php elseif($studentBundle->studentRequirement->status == 'rejected'): ?>
                            <div class="w-100 text-center">
                                <p class="alert alert-danger text-center text-white">
                                    لقد تم رفض الملفات التي قمت برفعها يرجي مراجعة الميل لمشاهدة السبب ثم ارفع الملفات مرة
                                    اخري
                                </p>
                                <a href="/panel/bundles/<?php echo e($studentBundle->id); ?>/requirements"
                                    class="btn btn-primary p-5 mt-20">للذهاب
                                    لرفع الملفات مرة اخري اضغط هنا</a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php else: ?>
       <section class="w-100 text-center">
           <p class="alert alert-info text-center">
             لم يتم التسجيل في اي دبلومه بعد
           </p>
           <a href="/apply" class="btn bg-secondary text-white p-5 mt-20">للتسجيل اضغط علي هذا اللينك</a>
       </section>
       <?php endif; ?>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts_bottom'); ?>
    <script src="/assets/vendors/cropit/jquery.cropit.js"></script>
    <script src="/assets/default/js/parts/img_cropit.min.js"></script>
    <script src="/assets/default/vendors/select2/select2.min.js"></script>

    <script>
        var editEducationLang = '<?php echo e(trans('site.edit_education')); ?>';
        var editExperienceLang = '<?php echo e(trans('site.edit_experience')); ?>';
        var saveSuccessLang = '<?php echo e(trans('webinars.success_store')); ?>';
        var saveErrorLang = '<?php echo e(trans('site.store_error_try_again')); ?>';
        var notAccessToLang = '<?php echo e(trans('public.not_access_to_this_content')); ?>';
    </script>

    <script src="/assets/default/js/panel/user_setting.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(getTemplate() . '.panel.layouts.panel_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\lms\resources\views/web/default/panel/requirements/index.blade.php ENDPATH**/ ?>