<form method="post" id="userRequirmentForm" class="mt-30" enctype="multipart/form-data"
    action="<?php echo e('/panel/requirements'); ?>">
    <?php echo e(csrf_field()); ?>


    <h1 class="section-title after-line text-center ">نموذج تقديم متطلبات القبول</h1>

    <div class="row mt-20 p-5">

        
        <div class="col-12 col-lg-6">

            <div class="form-group p-5 ">
                <label for="user_code">رقم الطالب *</label>
                <input type="text" name="user_code" id="user_code"
                    class="form-control <?php $__errorArgs = ['user_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required readonly
                    value="<?php echo e($user_code); ?>" />
                <?php $__errorArgs = ['user_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>


            <div class="form-group p-5 ">
                <label for="program">البرنامج المراد التسجيل فيه *</label>


                <input type="text" name="program" id="program"
                    class="form-control <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required readonly
                    value="<?php echo e(preg_replace('/\s+/', ' ', trim($program))); ?>" />

                <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="form-group p-5 ">
                <label for="specialization">التخصص المطلوب *</label>

                <input type="text" name="specialization" id="specialization"
                    class="form-control <?php $__errorArgs = ['specialization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required readonly
                    value="<?php echo e($specialization); ?>" />

                <?php $__errorArgs = ['specialization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="form-group p-5 ">
                <label for="identity_type">اختر نوع الهوية المرفقة *</label>
                <select id="identity_type" class="form-control d-block <?php $__errorArgs = ['identity_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="identity_type" required>
                    <option value="" class="placeholder" disabled
                        <?php echo e(old('identity_type') == '' ? 'selected' : ''); ?>>اختر نوع الهوية
                    </option>
                    <option value="الهوية الوطنية" <?php echo e(old('identity_type') == 'الهوية الوطنية' ? 'selected' : ''); ?>>
                        الهوية الوطنية</option>
                    <option value="جواز السفر" <?php echo e(old('identity_type') == 'جواز السفر' ? 'selected' : ''); ?>>جواز السفر
                    </option>
                </select>
                <?php $__errorArgs = ['identity_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group p-5 <?php echo e(old('identity_type') != '' ? 'd-block' : 'd-none'); ?>"
                id="identity_attach">
                <label for="identity_attachment">ارفق صورة <?php echo e(old('identity_type')); ?> *</label>
                <input type="file" name="identity_attachment" id="identity_attachment"
                    class="form-control <?php $__errorArgs = ['identity_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" required
                    value="<?php echo e(old('identity_attachment')); ?>" accept=".pdf,.jpeg,.jpg,.png" />
                <?php $__errorArgs = ['identity_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-primary">.PDF JPEG JPG PNG امتداد الملف المسموح به</p>
            </div>

            <div class="form-group p-5 ">

                <label for="admission_attachment">ارفق متطلبات القبول *</label>
                <input type="file" name="admission_attachment" id="admission_attachment"
                    class="form-control <?php $__errorArgs = ['admission_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" required
                    value="<?php echo e(old('admission_attachment')); ?>" accept="application/pdf" />
                <?php $__errorArgs = ['admission_attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <P class="text-primary">برجاء ارفاق المتطلبات من 2 الى نهاية المتطلبات في ملف واحد بصيغة PDF ولا يتعدي حجم الملف 20
                    ميجا</P>
            </div>

        </div>


        
        <div class="col-12 col-lg-5 ml-20">
            <?php if(preg_replace('/\s+/', ' ', trim($program)) == 'دبلوم متوسط'): ?>
                <?php echo $__env->make('web.default.panel.requirements.requirements_includes.Intermediate_Diploma_Program', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(preg_replace('/\s+/', ' ', trim($program)) == 'دبلوم عالي'): ?>
                <?php echo $__env->make('web.default.panel.requirements.requirements_includes.Higher_Diploma_Program', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(preg_replace('/\s+/', ' ', trim($program)) == 'ماجستير مهني'): ?>
                <?php echo $__env->make("web.default.panel.requirements.requirements_includes.Professional_Master's_Program", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(preg_replace('/\s+/', ' ', trim($program)) == 'ماجستير تنفليذي'): ?>
                <?php echo $__env->make("web.default.panel.requirements.requirements_includes.Professional_Master's_Program", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>


    <div class="d-flex align-items-baseline">
        <input type="checkbox" name="accept" class="d-inline-block mr-10" required>
        <p>اقر أنا المسجل بياناتي اعلاه بموافقتي على لائحة الحقوق والوجبات واحكام وشروط القبول والتسجيل، كما أقر
            بالتزامي
            التام بمضمونها، وبمسؤوليتي التامة عن أية مخالفات قد تصدر مني لها ، مما يترتب عليه كامل الأحقية للاكاديمية في
            مسائلتي عن تلك المخالفات والتصرفات المخالفة للوائح المشار إليها في عقد اتفاقية التحاق متدربـ/ـة
            <a href="https://anasacademy.uk/wp-content/uploads/2023/12/نموذج-عقد-اتفاقية-التحاق-متدربـ-النسخة-الاخيرة.pdf"
                target="_blank" class="text-primary">انقر هنا للمشاهدة</a>
        </p>
    </div>


    <button type="submit" name="submit" id="btn_submit" class="btn btn-primary mt-20" data-alt-text="جاري إرسال طلبك"
        data-submit-text="اضغط لإرسال متطلبات القبول" value="form_submit">اضغط لإرسال متطلبات القبول</button>


</form>

<script>
    let identity_type = document.getElementById('identity_type');
    let identity_attach = document.getElementById('identity_attach');
    identity_type.addEventListener('change', function() {
        identity_attach.classList.add("d-block");
        identity_attach.classList.remove("d-none");
        identity_attach.firstElementChild.innerText = " ارفق صورة  " + identity_type.value + " *";
    });

    document.onload = function() {
        if(identity_type.value!="")
        identity_attach.classList.add("d-block");
        identity_attach.classList.remove("d-none");
        identity_attach.firstElementChild.innerText = " ارفق صورة  " + identity_type.value + " *";
    };
</script>
<?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\New folder\lms-system-v1\resources\views/web/default/panel/requirements/requirements_includes/basic_information.blade.php ENDPATH**/ ?>