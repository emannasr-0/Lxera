<svg xmlns="http://www.w3.org/2000/svg" width="19.5" height="20.496" viewBox="0 0 19.5 20.496">
    <g id="Group_1266" transform="translate(-207.65 -516.252)">
        <g id="Group_1265">
            <g id="Icon_feather-bell" transform="translate(205.4 515.002)">
                <path id="Path_175" d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" class="cls-1"/>
                <path id="Path_176" d="M13.73 21a2 2 0 0 1-3.46 0" class="cls-1" transform="translate(0 -1)"/>
            </g>
        </g>
    </g>
</svg>
<?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\lms\resources\views/web/default/panel/includes/sidebar_icons/notifications.blade.php ENDPATH**/ ?>