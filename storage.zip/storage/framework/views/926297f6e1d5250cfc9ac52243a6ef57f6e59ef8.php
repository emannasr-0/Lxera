<button class="<?php if(empty($hideDefaultClass) or !$hideDefaultClass): ?> <?php echo e(!empty($noBtnTransparent) ? '' : 'btn-transparent'); ?> text-primary <?php endif; ?> <?php echo e($btnClass ?? ''); ?>"
        data-toggle="modal" data-target=<?php echo e("#confirmModal".$id); ?>

        data-confirm-href="<?php echo e($url); ?>"
        data-confirm-text-yes="<?php echo e(trans('admin/main.yes')); ?>"
        data-confirm-text-cancel="<?php echo e(trans('admin/main.cancel')); ?>"
        data-confirm-has-message="true"
>
    <?php if(!empty($btnText)): ?>
        <?php echo $btnText; ?>

    <?php else: ?>
        <i class="fa <?php echo e(!empty($btnIcon) ? $btnIcon : 'fa-times'); ?>" aria-hidden="true"></i>
    <?php endif; ?>
</button>

<!-- Modal -->
<div class="modal fade" id=<?php echo e("confirmModal".$id); ?> tabindex="-1" aria-labelledby="confirmModalLabel" aria-hidden="true" data-confirm-href="<?php echo e($url); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmModalLabel"><?php echo e("تأكيد رفض الطلب"); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="modal-body" method="GET" action="<?php echo e($url); ?>" id="deleteForm">
                <label for="message"><?php echo e("اذكر سبب الرفض"); ?></label>
                <textarea class="form-control" id="message" name="message"></textarea>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary ml-3" data-dismiss="modal"><?php echo e(trans('admin/main.cancel')); ?></button>
                    <button type="submit" class="btn btn-danger id="confirmAction"><?php echo e(trans('admin/main.send')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\lms\resources\views/admin/includes/confirm_delete_button.blade.php ENDPATH**/ ?>