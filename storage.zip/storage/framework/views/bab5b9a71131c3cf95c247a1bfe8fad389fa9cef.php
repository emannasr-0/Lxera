<?php $__env->startPush('styles_top'); ?>
    <link rel="stylesheet" href="/assets/default/vendors/select2/select2.min.css">
    <link rel="stylesheet" href="/assets/default/vendors/daterangepicker/daterangepicker.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('web.default.panel.requirements.requirements_includes.progress', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(Session::has('success')): ?>
        <div class="container d-flex justify-content-center mt-80">
            <p class="alert alert-success w-75 text-center"> <?php echo e(Session::get('success')); ?> </p>
        </div>
    <?php else: ?>
        <?php if(!$requirementUploaded || $requirementStatus=="rejected"): ?>
            <?php echo $__env->make('web.default.panel.requirements.requirements_includes.basic_information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
        <div class="container mt-80 text-center ">
            <p class="alert alert-success text-center">
        لقد تم بالفعل رفع متطلبات القبول يرجي الذهاب لصفحة المتطلبات لرؤية حالة الطلب
            </p>
            <a href="/panel/requirements"
                class="btn btn-primary p-5 mt-20">للذهاب لصفحة متطلبات القبول برجي الضغط هنا</a>
        </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts_bottom'); ?>
    <script src="/assets/vendors/cropit/jquery.cropit.js"></script>
    <script src="/assets/default/js/parts/img_cropit.min.js"></script>
    <script src="/assets/default/vendors/select2/select2.min.js"></script>

    <script>
        var editEducationLang = '<?php echo e(trans('site.edit_education')); ?>';
        var editExperienceLang = '<?php echo e(trans('site.edit_experience')); ?>';
        var saveSuccessLang = '<?php echo e(trans('webinars.success_store')); ?>';
        var saveErrorLang = '<?php echo e(trans('site.store_error_try_again')); ?>';
        var notAccessToLang = '<?php echo e(trans('public.not_access_to_this_content')); ?>';
    </script>

    <script src="/assets/default/js/panel/user_setting.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(getTemplate() . '.panel.layouts.panel_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\OneDrive - اكاديمية انس للفنون البصرية\Desktop\lms\resources\views/web/default/panel/requirements/create.blade.php ENDPATH**/ ?>