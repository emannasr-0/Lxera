<?php return array (
  'enroller-actions' => 'App\\Http\\Livewire\\EnrollerActions',
  'register-bundles' => 'App\\Http\\Livewire\\RegisterBundles',
  'registered-student-actions' => 'App\\Http\\Livewire\\RegisteredStudentActions',
  'requirment-actions' => 'App\\Http\\Livewire\\RequirmentActions',
  'student-actions' => 'App\\Http\\Livewire\\StudentActions',
);